package com.servicehub.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.servicehub.exception.ApiException;
import com.servicehub.model.*;
import com.servicehub.dto.*;
import com.servicehub.repository.*;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class ServiceRequestService {
  private final UserRepository users;
  private final ServiceOfferingRepository offerings;
  private final ServiceRequestRepository requests;
  private final ReviewRepository reviews;
  private final PatchSupport patches;

  private ServiceRequest entity(Long id) {
    return requests.findById(id).orElseThrow(() -> ApiException.notFound("ServiceRequest", id));
  }

  @Transactional(readOnly = true)
  public List<ServiceRequestResponse> findAll() {
    return requests.findAll(org.springframework.data.domain.Sort.by("id")).stream()
        .map(ServiceRequestResponse::from)
        .toList();
  }

  @Transactional(readOnly = true)
  public ServiceRequestResponse findById(Long id) {
    return ServiceRequestResponse.from(entity(id));
  }

  public ServiceRequestResponse create(ServiceRequestInput dto) {
    ServiceRequest e = new ServiceRequest();
    apply(e, dto);
    return ServiceRequestResponse.from(requests.saveAndFlush(e));
  }

  public ServiceRequestResponse update(Long id, ServiceRequestInput dto) {
    ServiceRequest e = entity(id);
    apply(e, dto);
    return ServiceRequestResponse.from(requests.saveAndFlush(e));
  }

  public void delete(Long id) {
    ServiceRequest e = entity(id);
    if (reviews.existsByRequestId(id)) throw ApiException.conflict("Pedido possui avaliação.");
    requests.delete(e);
    requests.flush();
  }

  private void apply(ServiceRequest e, ServiceRequestInput dto) {
    ServiceOffering offering =
        offerings
            .findById(dto.serviceId())
            .orElseThrow(() -> ApiException.notFound("Serviço", dto.serviceId()));
    User client =
        users
            .findById(dto.clientId())
            .orElseThrow(() -> ApiException.notFound("Cliente", dto.clientId()));
    if (e.getId() == null) {
      if (client.getRole() != UserRole.CLIENT)
        throw ApiException.conflict("Solicitação exige um usuário CLIENT.");
      if (!offering.isActive() || !offering.getProvider().isActive() || !client.isActive())
        throw ApiException.conflict("Serviço, prestador e cliente devem estar ativos.");
      if (offering.getProvider().getId().equals(client.getId()))
        throw ApiException.conflict("Prestador não pode contratar o próprio serviço.");
      if (dto.status() != RequestStatus.PENDING)
        throw ApiException.conflict("Novo pedido deve iniciar em PENDING.");
      e.setTotalPrice(offering.getPrice());
    } else {
      if (!e.getService().getId().equals(dto.serviceId())
          || !e.getClient().getId().equals(dto.clientId()))
        throw ApiException.conflict("Serviço e cliente do pedido são imutáveis.");
      RequestStatus current = e.getStatus(), next = dto.status();
      boolean allowed =
          current == next
              || (current == RequestStatus.PENDING
                  && (next == RequestStatus.ACCEPTED || next == RequestStatus.CANCELLED))
              || (current == RequestStatus.ACCEPTED
                  && (next == RequestStatus.IN_PROGRESS || next == RequestStatus.CANCELLED))
              || (current == RequestStatus.IN_PROGRESS
                  && (next == RequestStatus.COMPLETED || next == RequestStatus.CANCELLED));
      if (!allowed)
        throw ApiException.conflict("Transição de status inválida: " + current + " para " + next);
    }
    e.setStatus(dto.status());
    e.setScheduledAt(dto.scheduledAt());
    e.setNotes(TextSanitizer.plainText(dto.notes()));
    e.setService(offering);
    e.setClient(client);
  }

  @Transactional(readOnly = true)
  public PageResponse<ServiceRequestResponse> list(RequestStatus status, Pageable pageable) {
    Specification<ServiceRequest> filter =
        (r, q, b) -> status == null ? b.conjunction() : b.equal(r.get("status"), status);
    return PageResponse.from(
        requests
            .findAll(
                filter,
                PaginationSupport.check(
                    pageable, "id", "status", "scheduledAt", "createdAt", "totalPrice"))
            .map(ServiceRequestResponse::from));
  }

  @Transactional(readOnly = true)
  public PageResponse<ServiceRequestResponse> byClient(Long id, Pageable pageable) {
    if (!users.existsById(id)) throw ApiException.notFound("Cliente", id);
    return PageResponse.from(
        requests
            .findByClientId(id, PaginationSupport.check(pageable, "id", "status", "createdAt"))
            .map(ServiceRequestResponse::from));
  }

  public ServiceRequestResponse patch(Long id, JsonNode patch) {
    ServiceRequest e = entity(id);
    ServiceRequestInput current =
        new ServiceRequestInput(
            e.getService().getId(),
            e.getClient().getId(),
            e.getStatus(),
            e.getScheduledAt(),
            e.getNotes());
    apply(e, patches.merge(current, patch, ServiceRequestInput.class, Set.of()));
    return ServiceRequestResponse.from(requests.saveAndFlush(e));
  }
}
