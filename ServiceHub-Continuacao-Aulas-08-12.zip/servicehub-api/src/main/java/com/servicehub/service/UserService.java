package com.servicehub.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.servicehub.exception.ApiException;
import com.servicehub.model.*;
import com.servicehub.dto.*;
import com.servicehub.repository.*;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class UserService {
  private final UserRepository users;
  private final ServiceOfferingRepository offerings;
  private final ServiceRequestRepository requests;
  private final ReviewRepository reviews;
  private final PatchSupport patches;

  private User entity(Long id) {
    return users.findById(id).orElseThrow(() -> ApiException.notFound("User", id));
  }

  @Transactional(readOnly = true)
  public List<UserResponse> findAll() {
    return users.findAll(org.springframework.data.domain.Sort.by("id")).stream()
        .map(UserResponse::from)
        .toList();
  }

  @Transactional(readOnly = true)
  public UserResponse findById(Long id) {
    return UserResponse.from(entity(id));
  }

  public UserResponse create(UserInput dto) {
    if (dto.role() == UserRole.ADMIN)
      throw new ApiException(org.springframework.http.HttpStatus.BAD_REQUEST, "Não é permitido cadastrar ADMIN pela API pública.");
    User e = new User();
    apply(e, dto);
    return UserResponse.from(users.saveAndFlush(e));
  }

  public UserResponse update(Long id, UserInput dto) {
    User e = entity(id);
    apply(e, dto);
    return UserResponse.from(users.saveAndFlush(e));
  }

  public void delete(Long id) {
    User e = entity(id);
    if (offerings.existsByProviderId(id)
        || requests.existsByClientId(id)
        || reviews.existsByReviewerId(id))
      throw ApiException.conflict("Usuário possui registros relacionados.");
    users.delete(e);
    users.flush();
  }

  private void apply(User e, UserInput dto) {
    String email = dto.email().strip().toLowerCase(java.util.Locale.ROOT);
    if (e.getId() == null
        ? users.existsByEmailIgnoreCase(email)
        : users.existsByEmailIgnoreCaseAndIdNot(email, e.getId()))
      throw new com.servicehub.exception.EmailAlreadyExistsException();
    if (dto.password() != null
        && dto.password().getBytes(java.nio.charset.StandardCharsets.UTF_8).length > 72)
      throw new ApiException(
          org.springframework.http.HttpStatus.BAD_REQUEST, "Senha excede 72 bytes UTF-8.");
    if (e.getId() != null
        && dto.role() != e.getRole()
        && (offerings.existsByProviderId(e.getId()) || requests.existsByClientId(e.getId())))
      throw ApiException.conflict(
          "Não é possível mudar o papel de um usuário com serviços ou pedidos.");
    e.setRole(dto.role());
    e.setFullName(TextSanitizer.plainText(dto.fullName()));
    e.setPhone(dto.phone());
    e.setBio(TextSanitizer.plainText(dto.bio()));
    e.setAvatarUrl(dto.avatarUrl());
    e.setActive(dto.active());
    e.setEmail(email);
    if (dto.password() != null)
      e.setPasswordHash(
          new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder()
              .encode(dto.password()));
  }

  @Transactional(readOnly = true)
  public PageResponse<UserResponse> list(String email, Pageable pageable) {
    Specification<User> filter =
        (r, q, b) ->
            email == null
                ? b.conjunction()
                : b.equal(
                    b.lower(r.get("email")), email.strip().toLowerCase(java.util.Locale.ROOT));
    return PageResponse.from(
        users
            .findAll(
                filter, PaginationSupport.check(pageable, "id", "fullName", "email", "createdAt"))
            .map(UserResponse::from));
  }

  public UserResponse patch(Long id, JsonNode patch) {
    if (patch.has("role") && "ADMIN".equalsIgnoreCase(patch.path("role").asText()))
      throw new ApiException(org.springframework.http.HttpStatus.BAD_REQUEST, "Não é permitido atribuir ADMIN por PATCH.");
    User e = entity(id);
    UserInput current =
        new UserInput(
            e.getFullName(),
            e.getEmail(),
            null,
            e.getPhone(),
            e.getBio(),
            e.getAvatarUrl(),
            e.isActive(),
            e.getRole());
    UserInput merged = patches.merge(current, patch, UserInput.class, Set.of("password"));
    apply(e, merged);
    return UserResponse.from(users.saveAndFlush(e));
  }
}
