package com.servicehub.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.servicehub.exception.ApiException;
import com.servicehub.model.*;
import com.servicehub.dto.*;
import com.servicehub.repository.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class ServiceOfferingService {
  private final UserRepository users;
  private final ServiceOfferingRepository offerings;
  private final ServiceRequestRepository requests;
  private final PatchSupport patches;

  private ServiceOffering entity(Long id) {
    return offerings.findById(id).orElseThrow(() -> ApiException.notFound("ServiceOffering", id));
  }

  @Transactional(readOnly = true)
  public List<ServiceOfferingResponse> findAll() {
    return offerings.findAll(org.springframework.data.domain.Sort.by("id")).stream()
        .map(ServiceOfferingResponse::from)
        .toList();
  }

  @Transactional(readOnly = true)
  public ServiceOfferingResponse findById(Long id) {
    return ServiceOfferingResponse.from(entity(id));
  }

  public ServiceOfferingResponse create(ServiceOfferingInput dto) {
    ServiceOffering e = new ServiceOffering();
    apply(e, dto);
    return ServiceOfferingResponse.from(offerings.saveAndFlush(e));
  }

  public ServiceOfferingResponse update(Long id, ServiceOfferingInput dto) {
    ServiceOffering e = entity(id);
    apply(e, dto);
    return ServiceOfferingResponse.from(offerings.saveAndFlush(e));
  }

  public void delete(Long id) {
    ServiceOffering e = entity(id);
    if (requests.existsByServiceId(id)) throw ApiException.conflict("Serviço possui pedidos.");
    offerings.delete(e);
    offerings.flush();
  }

  private void apply(ServiceOffering e, ServiceOfferingInput dto) {
    User provider =
        users
            .findById(dto.providerId())
            .orElseThrow(() -> ApiException.notFound("Prestador", dto.providerId()));
    if (provider.getRole() != UserRole.PROVIDER)
      throw ApiException.conflict("Somente usuários PROVIDER podem possuir serviços.");
    if (!provider.isActive()) throw ApiException.conflict("Prestador inativo.");
    e.setTitle(TextSanitizer.plainText(dto.title()));
    e.setDescription(TextSanitizer.plainText(dto.description()));
    e.setPrice(dto.price());
    e.setCategory(dto.category());
    e.setActive(dto.active());
    e.setProvider(provider);
  }

  @Transactional(readOnly = true)
  public List<ServiceOfferingResponse> byProvider(Long id) {
    if (!users.existsById(id)) throw ApiException.notFound("Prestador", id);
    return offerings.findByProviderIdAndActiveTrue(id).stream()
        .map(ServiceOfferingResponse::from)
        .toList();
  }

  @Transactional(readOnly = true)
  public PageResponse<ServiceOfferingResponse> list(
      ServiceCategory category,
      BigDecimal minPrice,
      BigDecimal maxPrice,
      Boolean active,
      Long providerId,
      Pageable pageable) {
    if ((minPrice != null && minPrice.signum() < 0)
        || (maxPrice != null && maxPrice.signum() < 0)
        || (minPrice != null && maxPrice != null && minPrice.compareTo(maxPrice) > 0))
      throw new ApiException(
          org.springframework.http.HttpStatus.BAD_REQUEST, "Faixa de preço inválida.");
    Specification<ServiceOffering> filter =
        (r, q, b) -> {
          java.util.List<jakarta.persistence.criteria.Predicate> conditions =
              new java.util.ArrayList<>();
          if (category != null) conditions.add(b.equal(r.get("category"), category));
          if (minPrice != null) conditions.add(b.greaterThanOrEqualTo(r.get("price"), minPrice));
          if (maxPrice != null) conditions.add(b.lessThanOrEqualTo(r.get("price"), maxPrice));
          if (active != null) conditions.add(b.equal(r.get("active"), active));
          if (providerId != null) conditions.add(b.equal(r.get("provider").get("id"), providerId));
          return b.and(conditions.toArray(jakarta.persistence.criteria.Predicate[]::new));
        };
    return PageResponse.from(
        offerings
            .findAll(
                filter,
                PaginationSupport.check(pageable, "id", "title", "price", "category", "createdAt"))
            .map(ServiceOfferingResponse::from));
  }

  @Transactional(readOnly = true)
  public PageResponse<ServiceOfferingResponse> providerServices(Long id, Pageable pageable) {
    if (!users.existsById(id)) throw ApiException.notFound("Usuário", id);
    return list(null, null, null, true, id, pageable);
  }

  public ServiceOfferingResponse patch(Long id, JsonNode patch) {
    ServiceOffering e = entity(id);
    ServiceOfferingInput current =
        new ServiceOfferingInput(
            e.getTitle(),
            e.getDescription(),
            e.getPrice(),
            e.getCategory(),
            e.getProvider().getId(),
            e.isActive());
    apply(e, patches.merge(current, patch, ServiceOfferingInput.class, Set.of()));
    return ServiceOfferingResponse.from(offerings.saveAndFlush(e));
  }
}
