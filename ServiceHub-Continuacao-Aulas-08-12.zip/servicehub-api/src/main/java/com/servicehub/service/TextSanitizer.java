package com.servicehub.service;

import org.apache.commons.text.StringEscapeUtils;

/** Sanitização de texto livre no service, conforme a Aula 08. */
public final class TextSanitizer {
  private TextSanitizer() {}

  public static String plainText(String value) {
    if (value == null) return null;
    String normalized = value.replace(String.valueOf((char) 0), "").strip();
    return StringEscapeUtils.escapeHtml4(normalized);
  }
}
