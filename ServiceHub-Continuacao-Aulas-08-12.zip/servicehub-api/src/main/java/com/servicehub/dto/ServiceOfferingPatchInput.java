package com.servicehub.dto;

import com.servicehub.model.*;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;

@Schema(
    description =
        "Dados para criar ou substituir ServiceOffering. PATCH altera somente campos enviados; null"
            + " limpa campos opcionais.")
public record ServiceOfferingPatchInput(
    @Schema(description = "Título do serviço", example = "Manutenção de computador")
        @Size(max = 150)
        String title,
    @Schema(description = "Descrição do serviço", example = "Limpeza e diagnóstico")
        @Size(max = 5000)
        String description,
    @Schema(description = "Preço em reais", example = "150.00")
        @DecimalMin("0.01")
        @Digits(integer = 8, fraction = 2)
        BigDecimal price,
    @Schema(description = "Categoria", example = "TECNOLOGIA") ServiceCategory category,
    @Schema(description = "ID de usuário prestador", example = "1") @Positive Long providerId,
    @Schema(description = "Serviço disponível", example = "true") Boolean active) {}
