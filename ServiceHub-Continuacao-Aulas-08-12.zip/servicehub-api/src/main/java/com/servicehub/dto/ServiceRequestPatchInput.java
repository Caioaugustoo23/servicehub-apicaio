package com.servicehub.dto;

import com.servicehub.model.*;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Schema(
    description =
        "Dados para criar ou substituir ServiceRequest. PATCH altera somente campos enviados; null"
            + " limpa campos opcionais.")
public record ServiceRequestPatchInput(
    @Schema(description = "ID do serviço", example = "1") @Positive Long serviceId,
    @Schema(description = "ID do usuário cliente", example = "2") @Positive Long clientId,
    @Schema(description = "Situação; criação exige PENDING", example = "PENDING")
        RequestStatus status,
    @Schema(description = "Agendamento opcional, horário local", example = "2026-10-20T14:00:00")
        LocalDateTime scheduledAt,
    @Schema(description = "Observações", example = "Computador não liga") @Size(max = 5000)
        String notes) {}
