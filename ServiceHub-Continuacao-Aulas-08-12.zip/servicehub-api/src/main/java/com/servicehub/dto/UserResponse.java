package com.servicehub.dto;

import com.servicehub.model.*;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDateTime;

@Schema(description = "Representação de User, sem senha ou hash.")
public record UserResponse(
    @Schema(description = "Identificador", example = "1") Long id,
    @Schema(description = "Nome completo", example = "Maria Silva") String fullName,
    @Schema(description = "E-mail único", example = "maria@example.com") String email,
    @Schema(description = "Telefone opcional", example = "11999999999") String phone,
    @Schema(description = "Apresentação do usuário", example = "Técnica em informática") String bio,
    @Schema(description = "URL opcional da foto", example = "https://example.com/avatar.png")
        String avatarUrl,
    @Schema(description = "Cadastro ativo", example = "true") Boolean active,
    @Schema(description = "Papel do usuário", example = "PROVIDER") UserRole role,
    @Schema(description = "Data de criação", example = "2026-09-14T10:00:00")
        LocalDateTime createdAt,
    @Schema(description = "Data da última alteração", example = "2026-09-14T10:00:00")
        LocalDateTime updatedAt) {
  public static UserResponse from(User e) {
    return new UserResponse(
        e.getId(),
        e.getFullName(),
        e.getEmail(),
        e.getPhone(),
        e.getBio(),
        e.getAvatarUrl(),
        e.isActive(),
        e.getRole(),
        e.getCreatedAt(),
        e.getUpdatedAt());
  }
}
