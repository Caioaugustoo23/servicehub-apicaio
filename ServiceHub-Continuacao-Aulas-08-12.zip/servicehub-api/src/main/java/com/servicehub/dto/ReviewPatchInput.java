package com.servicehub.dto;

import com.servicehub.model.*;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;

@Schema(
    description =
        "Dados para criar ou substituir Review. PATCH altera somente campos enviados; null limpa"
            + " campos opcionais.")
public record ReviewPatchInput(
    @Schema(description = "Pedido concluído avaliado", example = "1") @Positive Long requestId,
    @Schema(description = "ID do cliente do pedido", example = "2") @Positive Long reviewerId,
    @Schema(description = "Nota de 1 a 5", example = "5") @Min(1) @Max(5) Integer rating,
    @Schema(description = "Comentário", example = "Ótimo atendimento") @Size(max = 5000)
        String comment) {}
