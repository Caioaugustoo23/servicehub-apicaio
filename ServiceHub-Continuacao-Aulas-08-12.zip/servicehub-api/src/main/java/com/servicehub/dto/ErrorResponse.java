package com.servicehub.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.Instant;
import java.util.Map;

@Schema(description = "Erro HTTP padronizado, sem detalhes internos do servidor")
public record ErrorResponse(
    @Schema(description = "Instante UTC", example = "2026-09-21T14:00:00Z") Instant timestamp,
    @Schema(description = "Código HTTP", example = "400") int status,
    @Schema(description = "Nome do status", example = "Bad Request") String error,
    @Schema(description = "Mensagem para o consumidor", example = "Dados inválidos") String message,
    @Schema(description = "Caminho solicitado", example = "/api/v1/users") String path,
    @Schema(
            description = "Mensagens por campo",
            example = "{\"email\":\"deve ser um endereço de e-mail bem formado\"}")
        Map<String, String> fieldErrors) {}
