package com.servicehub.dto;

import com.servicehub.model.*;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Schema(description = "Representação de ServiceRequest, sem senha ou hash.")
public record ServiceRequestResponse(
    @Schema(description = "Identificador", example = "1") Long id,
    @Schema(description = "ID do serviço", example = "1") Long serviceId,
    @Schema(description = "ID do usuário cliente", example = "2") Long clientId,
    @Schema(description = "Situação; criação exige PENDING", example = "PENDING")
        RequestStatus status,
    @Schema(description = "Agendamento opcional, horário local", example = "2026-10-20T14:00:00")
        LocalDateTime scheduledAt,
    @Schema(description = "Observações", example = "Computador não liga") String notes,
    @Schema(description = "Preço registrado no pedido", example = "150.00") BigDecimal totalPrice,
    @Schema(description = "Data de criação", example = "2026-09-14T10:00:00")
        LocalDateTime createdAt,
    @Schema(description = "Data da última alteração", example = "2026-09-14T10:00:00")
        LocalDateTime updatedAt) {
  public static ServiceRequestResponse from(ServiceRequest e) {
    return new ServiceRequestResponse(
        e.getId(),
        e.getService().getId(),
        e.getClient().getId(),
        e.getStatus(),
        e.getScheduledAt(),
        e.getNotes(),
        e.getTotalPrice(),
        e.getCreatedAt(),
        e.getUpdatedAt());
  }
}
