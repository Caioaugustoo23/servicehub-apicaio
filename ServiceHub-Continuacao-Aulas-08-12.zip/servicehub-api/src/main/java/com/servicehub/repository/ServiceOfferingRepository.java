package com.servicehub.repository;

import com.servicehub.model.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceOfferingRepository
    extends JpaRepository<ServiceOffering, Long>,
        org.springframework.data.jpa.repository.JpaSpecificationExecutor<ServiceOffering> {
  boolean existsByProviderId(Long providerId);

  java.util.List<ServiceOffering> findByCategory(ServiceCategory category);

  java.util.List<ServiceOffering> findByPriceBetween(
      java.math.BigDecimal min, java.math.BigDecimal max);

  java.util.List<ServiceOffering> findByProviderIdAndActiveTrue(Long providerId);

  long countByCategory(ServiceCategory category);
}
