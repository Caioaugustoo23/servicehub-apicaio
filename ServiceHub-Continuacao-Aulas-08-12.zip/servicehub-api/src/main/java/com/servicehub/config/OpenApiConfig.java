package com.servicehub.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
  @Bean
  OpenAPI serviceHubOpenAPI() {
    return new OpenAPI()
        .servers(java.util.List.of(new Server().url("/")))
        .info(
            new Info()
                .title("ServiceHub API")
                .version("v1.0.0")
                .description(
                    "Projeto acadêmico de Caio Augusto Martins de Andrade, matrícula 2411945."
                        + " Plataforma de contratação de serviços. CRUD, PATCH, paginação e"
                        + " filtros. Endpoints públicos para demonstração local; JWT apenas"
                        + " documentado.")
                .contact(new Contact().name("Caio Augusto Martins de Andrade - matrícula 2411945"))
                .license(new License().name("Uso acadêmico - demais direitos reservados")))
        .components(
            new Components()
                .addSecuritySchemes(
                    "bearerAuth",
                    new SecurityScheme()
                        .type(SecurityScheme.Type.HTTP)
                        .scheme("bearer")
                        .bearerFormat("JWT")
                        .description(
                            "Esquema reservado à futura autenticação; tokens não são emitidos ou"
                                + " validados nesta versão.")));
  }

  @Bean
  GroupedOpenApi publicApi() {
    return GroupedOpenApi.builder().group("publico").pathsToMatch("/api/**").build();
  }

  @Bean
  GroupedOpenApi usersApi() {
    return GroupedOpenApi.builder().group("usuarios").pathsToMatch("/api/v1/users/**").build();
  }
}
