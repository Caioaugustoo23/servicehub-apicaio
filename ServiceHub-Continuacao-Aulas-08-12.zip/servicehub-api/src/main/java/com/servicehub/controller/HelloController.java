package com.servicehub.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@Tag(name = "Diagnóstico", description = "Rotas de teste da aula 3")
public class HelloController {
  @Schema(description = "Estado da aplicação")
  public record StatusResponse(
      @Schema(example = "OK", description = "Estado") String status,
      @Schema(example = "1.0.0", description = "Versão") String versao,
      @Schema(example = "ServiceHub API está no ar!", description = "Mensagem") String mensagem) {}

  @GetMapping("/hello")
  @Operation(
      summary = "Testar API",
      description = "Retorna mensagem de sucesso em JSON, conforme a entrega da aula 3.")
  public StatusResponse hello() {
    return new StatusResponse("OK", "1.0.0", "ServiceHub API está no ar!");
  }

  @GetMapping("/status")
  @Operation(
      summary = "Consultar estado",
      description = "Verifica se o servidor responde a requisições.")
  public StatusResponse status() {
    return hello();
  }

  @GetMapping("/info")
  @Operation(
      summary = "Consultar versão",
      description = "Retorna status, versão e mensagem da aplicação.")
  public StatusResponse info() {
    return hello();
  }
}
