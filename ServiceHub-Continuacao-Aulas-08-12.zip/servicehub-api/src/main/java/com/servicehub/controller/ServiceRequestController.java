package com.servicehub.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.servicehub.model.*;
import com.servicehub.dto.*;
import com.servicehub.service.ServiceRequestService;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping(value = "/api/v1/service-requests", produces = "application/json")
@Tag(
    name = "Pedidos de serviço",
    description = "Operações de pedidos de serviço da plataforma ServiceHub")
@RequiredArgsConstructor
public class ServiceRequestController {
  private final ServiceRequestService service;

  @PostMapping(value = "", consumes = "application/json")
  @Operation(
      operationId = "createServiceRequest",
      summary = "Cadastrar pedidos de serviço",
      description =
          "Contrata um serviço para um cliente. Inicia em PENDING e copia o preço atual da oferta"
              + " para totalPrice.")
  @ApiResponses({
    @ApiResponse(
        responseCode = "201",
        description = "pedido criado.",
        headers =
            @io.swagger.v3.oas.annotations.headers.Header(
                name = "Location",
                description = "URI do recurso criado",
                schema = @Schema(type = "string"))),
    @ApiResponse(
        responseCode = "400",
        description = "entrada inválida.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "serviço ou cliente ausente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "contratação incompatível.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasRole('CLIENT')")
  public ResponseEntity<ServiceRequestResponse> create(
      @Valid @RequestBody ServiceRequestInput dto) {
    var created = service.create(dto);
    return ResponseEntity.created(java.net.URI.create("/api/v1/service-requests/" + created.id()))
        .body(created);
  }

  @GetMapping("")
  @Operation(
      operationId = "listServiceRequest",
      summary = "Listar pedidos de serviço com paginação",
      description =
          "Retorna uma página de pedidos de serviço. page começa em 0, size tem máximo de 100 e"
              + " sort aceita campo,direção. Os filtros informados são combinados.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Página de pedidos de serviço."),
    @ApiResponse(
        responseCode = "400",
        description = "Parâmetros inválidos.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('CLIENT','PROVIDER','ADMIN')")
  public ResponseEntity<PageResponse<ServiceRequestResponse>> list(
      @Parameter(description = "Estado das solicitações") @RequestParam(required = false)
          RequestStatus status,
      @ParameterObject @PageableDefault(sort = "id", size = 20) Pageable pageable) {
    return ResponseEntity.ok(service.list(status, pageable));
  }

  @GetMapping("/{id}")
  @Operation(
      operationId = "getServiceRequest",
      summary = "Consultar pedidos de serviço por ID",
      description = "Consulta a contratação identificada, incluindo agendamento e observações.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "pedido."),
    @ApiResponse(
        responseCode = "400",
        description = "ID inválido.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "pedido inexistente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('CLIENT','PROVIDER','ADMIN')")
  public ResponseEntity<ServiceRequestResponse> get(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id) {
    return ResponseEntity.ok(service.findById(id));
  }

  @PutMapping(value = "/{id}", consumes = "application/json")
  @Operation(
      operationId = "updateServiceRequest",
      summary = "Substituir pedidos de serviço",
      description =
          "Atualiza status, agendamento e observações. Exige os mesmos IDs de cliente e serviço e"
              + " preserva totalPrice.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "pedido atualizado."),
    @ApiResponse(
        responseCode = "400",
        description = "entrada inválida.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "pedido ou referência ausente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "estado ou vínculo inválido.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('CLIENT','PROVIDER','ADMIN')")
  public ResponseEntity<ServiceRequestResponse> update(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id,
      @Valid @RequestBody ServiceRequestInput dto) {
    return ResponseEntity.ok(service.update(id, dto));
  }

  @DeleteMapping("/{id}")
  @Operation(
      operationId = "deleteServiceRequest",
      summary = "Excluir pedidos de serviço",
      description = "Remove a contratação somente se ela ainda não possuir avaliação vinculada.")
  @ApiResponses({
    @ApiResponse(responseCode = "204", description = "excluído.", content = @Content),
    @ApiResponse(
        responseCode = "400",
        description = "ID inválido.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "pedido inexistente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "pedido possui avaliação.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('CLIENT','PROVIDER','ADMIN')")
  public ResponseEntity<Void> delete(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id) {
    service.delete(id);
    return ResponseEntity.noContent().build();
  }

  @PatchMapping(value = "/{id}", consumes = "application/json")
  @Operation(
      operationId = "patchServiceRequest",
      summary = "Atualizar parcialmente pedidos de serviço",
      description =
          "Altera status, agendamento ou observações. Cliente e serviço não podem mudar. Preserva o"
              + " preço contratado e valida transições. Campos opcionais podem ser limpos com null."
              + " Campos obrigatórios não aceitam null. Campos desconhecidos são rejeitados.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Recurso atualizado"),
    @ApiResponse(
        responseCode = "400",
        description = "Dados inválidos",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "Recurso ou referência inexistente",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "Conflito de negócio",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('CLIENT','PROVIDER','ADMIN')")
  public ResponseEntity<ServiceRequestResponse> patch(
      @Parameter(description = "ID do recurso", example = "1") @PathVariable Long id,
      @io.swagger.v3.oas.annotations.parameters.RequestBody(
              required = true,
              description = "Campos a alterar",
              content = @Content(schema = @Schema(implementation = ServiceRequestPatchInput.class)))
          @RequestBody
          JsonNode patch) {
    return ResponseEntity.ok(service.patch(id, patch));
  }
}
