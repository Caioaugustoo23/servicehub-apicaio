package com.servicehub.model;

public enum UserRole {
  CLIENT,
  PROVIDER,
  ADMIN
}
