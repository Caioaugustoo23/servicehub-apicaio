package com.servicehub.model;

public enum RequestStatus {
  PENDING,
  ACCEPTED,
  IN_PROGRESS,
  COMPLETED,
  CANCELLED
}
