package com.servicehub.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.servicehub.model.User;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Base64;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/** Emissão e validação de tokens JWT HS256, sem armazenar estado no servidor. */
@Service
public class JwtService {
  private final ObjectMapper json;
  private final byte[] secret;
  private final long lifetimeSeconds;
  private final Base64.Encoder encoder = Base64.getUrlEncoder().withoutPadding();
  private final Base64.Decoder decoder = Base64.getUrlDecoder();

  public JwtService(
      ObjectMapper json,
      @Value("${app.jwt.secret:change-this-development-secret-to-a-long-random-value}") String secret,
      @Value("${app.jwt.expiration-seconds:3600}") long lifetimeSeconds) {
    if (secret.getBytes(StandardCharsets.UTF_8).length < 32)
      throw new IllegalArgumentException("app.jwt.secret deve ter pelo menos 32 bytes.");
    this.json = json;
    this.secret = secret.getBytes(StandardCharsets.UTF_8);
    this.lifetimeSeconds = lifetimeSeconds;
  }

  public String issue(User user) {
    try {
      String header = encoder.encodeToString("{\"alg\":\"HS256\",\"typ\":\"JWT\"}".getBytes(StandardCharsets.UTF_8));
      long now = Instant.now().getEpochSecond();
      String claims = json.writeValueAsString(java.util.Map.of(
          "sub", user.getEmail(), "uid", user.getId(), "role", user.getRole().name(),
          "iat", now, "exp", now + lifetimeSeconds));
      String payload = encoder.encodeToString(claims.getBytes(StandardCharsets.UTF_8));
      String unsigned = header + "." + payload;
      return unsigned + "." + encoder.encodeToString(sign(unsigned));
    } catch (Exception e) {
      throw new IllegalStateException("Não foi possível emitir o token.", e);
    }
  }

  public Claims verify(String token) {
    try {
      String[] parts = token.split("\\.");
      if (parts.length != 3) return null;
      byte[] expected = sign(parts[0] + "." + parts[1]);
      if (!MessageDigest.isEqual(expected, decoder.decode(parts[2]))) return null;
      var node = json.readTree(decoder.decode(parts[1]));
      if (!"HS256".equals(json.readTree(decoder.decode(parts[0])).path("alg").asText())) return null;
      if (node.path("exp").asLong(0) <= Instant.now().getEpochSecond()) return null;
      String email = node.path("sub").asText("");
      String role = node.path("role").asText("");
      long userId = node.path("uid").asLong(0);
      if (email.isBlank() || role.isBlank() || userId <= 0) return null;
      return new Claims(email, role, userId);
    } catch (Exception e) {
      return null;
    }
  }

  private byte[] sign(String value) throws Exception {
    Mac mac = Mac.getInstance("HmacSHA256");
    mac.init(new SecretKeySpec(secret, "HmacSHA256"));
    return mac.doFinal(value.getBytes(StandardCharsets.US_ASCII));
  }

  public record Claims(String email, String role, long userId) {}
}
