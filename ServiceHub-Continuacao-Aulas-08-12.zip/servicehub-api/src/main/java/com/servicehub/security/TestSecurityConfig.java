package com.servicehub.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/** Desabilita autenticação HTTP nos testes de integração, que focam regras de negócio. */
@Configuration
@Profile("test")
public class TestSecurityConfig {
  @Bean
  SecurityFilterChain testSecurityFilterChain(HttpSecurity http, DaoAuthenticationProvider daoAuthenticationProvider, JwtService jwt) throws Exception {
    http.csrf(csrf -> csrf.disable())
        .httpBasic(basic -> basic.disable())
        .formLogin(form -> form.disable())
        .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .authenticationProvider(daoAuthenticationProvider)
        .authorizeHttpRequests(auth -> auth.anyRequest().permitAll())
        .addFilterBefore(new JwtAuthenticationFilter(jwt), UsernamePasswordAuthenticationFilter.class);
    return http.build();
  }
}
