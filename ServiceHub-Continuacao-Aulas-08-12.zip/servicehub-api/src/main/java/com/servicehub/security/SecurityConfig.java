package com.servicehub.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableMethodSecurity
@Profile("!test")
public class SecurityConfig {
  @Bean
  SecurityFilterChain securityFilterChain(HttpSecurity http, JwtService jwt,
      DaoAuthenticationProvider daoAuthenticationProvider) throws Exception {
    http.csrf(csrf -> csrf.disable())
        .httpBasic(basic -> basic.disable())
        .formLogin(form -> form.disable())
        .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .authenticationProvider(daoAuthenticationProvider)
        .authorizeHttpRequests(auth -> auth
            .requestMatchers("/api/v1/auth/**", "/api/hello", "/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html", "/graphql", "/graphiql").permitAll()
            .requestMatchers(org.springframework.http.HttpMethod.POST, "/api/v1/users").permitAll()
            .requestMatchers("/api/v1/users", "/api/v1/users/**").hasRole("ADMIN")
            .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/v1/services", "/api/v1/services/**").permitAll()
            .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/v1/service-requests/**").hasAnyRole("CLIENT", "PROVIDER", "ADMIN")
            .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/v1/reviews/**").hasAnyRole("CLIENT", "ADMIN")
            .requestMatchers(org.springframework.http.HttpMethod.POST, "/api/v1/services", "/api/v1/services/**").hasAnyRole("PROVIDER", "ADMIN")
            .requestMatchers("/api/v1/services/**").hasAnyRole("PROVIDER", "ADMIN")
            .requestMatchers("/api/v1/service-requests/**").hasAnyRole("CLIENT", "PROVIDER", "ADMIN")
            .requestMatchers("/api/v1/reviews/**").hasAnyRole("CLIENT", "ADMIN")
            .anyRequest().authenticated())
        .addFilterBefore(new JwtAuthenticationFilter(jwt), UsernamePasswordAuthenticationFilter.class);
    return http.build();
  }
}
