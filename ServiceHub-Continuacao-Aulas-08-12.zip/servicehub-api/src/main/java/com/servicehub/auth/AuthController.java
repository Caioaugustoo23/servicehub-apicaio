package com.servicehub.auth;

import com.servicehub.repository.UserRepository;
import com.servicehub.security.JwtService;
import jakarta.validation.Valid;
import java.util.Locale;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;
import com.servicehub.exception.ApiException;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {
  private final UserRepository users;
  private final AuthenticationManager authenticationManager;
  private final JwtService jwt;
  private final long expiry;

  public AuthController(UserRepository users, AuthenticationManager authenticationManager, JwtService jwt,
      @Value("${app.jwt.expiration-seconds:3600}") long expiry) {
    this.users = users; this.authenticationManager = authenticationManager; this.jwt = jwt; this.expiry = expiry;
  }

  @PostMapping("/login")
  public LoginResponse login(@Valid @RequestBody LoginInput input) {
    String email = input.email().strip().toLowerCase(Locale.ROOT);
    try {
      authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, input.password()));
    } catch (AuthenticationException ex) {
      throw new ApiException(HttpStatus.UNAUTHORIZED, "E-mail ou senha inválidos.");
    }
    var user = users.findByEmailIgnoreCase(email)
        .filter(u -> u.isActive())
        .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "E-mail ou senha inválidos."));
    return new LoginResponse(jwt.issue(user), "Bearer", expiry, user.getId(), user.getEmail(), user.getRole().name());
  }
}
