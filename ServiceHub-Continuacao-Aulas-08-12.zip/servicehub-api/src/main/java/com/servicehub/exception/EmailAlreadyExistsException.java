package com.servicehub.exception;

public class EmailAlreadyExistsException extends ConflictException {
  public EmailAlreadyExistsException() {
    super("E-mail já cadastrado.");
  }
}
