package com.servicehub.exception;

import org.springframework.http.HttpStatus;

public class BusinessRuleException extends ApiException {
  public BusinessRuleException(String message) {
    super(HttpStatus.CONFLICT, message);
  }
}
