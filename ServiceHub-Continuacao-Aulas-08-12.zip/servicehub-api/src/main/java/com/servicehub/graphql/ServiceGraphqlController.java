package com.servicehub.graphql;

import com.servicehub.dto.ServiceOfferingResponse;
import com.servicehub.dto.ServiceRequestInput;
import com.servicehub.dto.ServiceRequestResponse;
import com.servicehub.model.RequestStatus;
import com.servicehub.model.UserRole;
import com.servicehub.repository.UserRepository;
import com.servicehub.service.ServiceOfferingService;
import com.servicehub.service.ServiceRequestService;
import com.servicehub.service.UserService;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

/** Implementa a Opção A da Aula 09: providers, servicesByProvider e bookService. */
@Controller
public class ServiceGraphqlController {
  private final ServiceOfferingService services;
  private final ServiceRequestService requests;
  private final UserService users;
  private final UserRepository userRepository;

  public ServiceGraphqlController(ServiceOfferingService services, ServiceRequestService requests,
      UserService users, UserRepository userRepository) {
    this.services = services; this.requests = requests; this.users = users; this.userRepository = userRepository;
  }

  @QueryMapping
  public List<ServiceOfferingResponse> services(@Argument Integer limit) {
    int safeLimit = limit == null ? 100 : Math.max(1, Math.min(limit, 100));
    return services.findAll().stream().limit(safeLimit).toList();
  }

  @QueryMapping
  public ServiceOfferingResponse service(@Argument Long id) { return services.findById(id); }

  @QueryMapping
  public List<com.servicehub.dto.UserResponse> providers() {
    return users.findAll().stream().filter(u -> u.role() == UserRole.PROVIDER && Boolean.TRUE.equals(u.active())).toList();
  }

  @QueryMapping
  public List<ServiceOfferingResponse> servicesByProvider(@Argument Long providerId) {
    return services.byProvider(providerId);
  }

  @MutationMapping
  @PreAuthorize("hasRole('CLIENT')")
  public ServiceRequestResponse bookService(@Argument Long serviceId, @Argument String scheduledAt, @Argument String notes) {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication == null || !authentication.isAuthenticated())
      throw new org.springframework.security.access.AccessDeniedException("Autenticação obrigatória.");
    var client = userRepository.findByEmailIgnoreCase(authentication.getName())
        .filter(u -> u.getRole() == UserRole.CLIENT && u.isActive())
        .orElseThrow(() -> new org.springframework.security.access.AccessDeniedException("Cliente ativo não encontrado."));
    LocalDateTime schedule = scheduledAt == null || scheduledAt.isBlank() ? null : LocalDateTime.parse(scheduledAt);
    return requests.create(new ServiceRequestInput(serviceId, client.getId(), RequestStatus.PENDING, schedule, notes));
  }
}
