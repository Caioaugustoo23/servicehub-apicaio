ALTER TABLE users ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'CLIENT';
UPDATE users SET role = 'PROVIDER' WHERE id IN (SELECT provider_id FROM services);
ALTER TABLE users ADD CONSTRAINT chk_user_role CHECK (role IN ('CLIENT','PROVIDER'));
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_requests_status ON service_requests(status);
CREATE INDEX idx_requests_service ON service_requests(service_id);
CREATE INDEX idx_reviews_reviewer ON reviews(reviewer_id);
