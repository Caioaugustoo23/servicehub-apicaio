ALTER TABLE users DROP CONSTRAINT chk_user_role;
ALTER TABLE users ADD CONSTRAINT chk_user_role CHECK (role IN ('CLIENT', 'PROVIDER', 'ADMIN'));
CREATE INDEX IF NOT EXISTS idx_services_active_category_price ON services(is_active, category, price);
CREATE INDEX IF NOT EXISTS idx_requests_client_status ON service_requests(client_id, status);
CREATE INDEX IF NOT EXISTS idx_reviews_reviewer_rating ON reviews(reviewer_id, rating);
