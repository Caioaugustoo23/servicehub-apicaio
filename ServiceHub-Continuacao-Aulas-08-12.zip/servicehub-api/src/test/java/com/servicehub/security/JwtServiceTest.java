package com.servicehub.security;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.servicehub.model.User;
import com.servicehub.model.UserRole;
import org.junit.jupiter.api.Test;

class JwtServiceTest {
  private final JwtService jwt = new JwtService(new ObjectMapper(), "0123456789abcdef0123456789abcdef", 3600);

  @Test
  void validatesIssuedTokenAndRejectsTampering() {
    User user = new User();
    user.setId(42L);
    user.setEmail("client@example.com");
    user.setRole(UserRole.CLIENT);
    String token = jwt.issue(user);

    assertThat(jwt.verify(token)).isEqualTo(new JwtService.Claims("client@example.com", "CLIENT", 42L));
    assertThat(jwt.verify(token + "x")).isNull();
    assertThat(jwt.verify("invalid.token.value")).isNull();
  }
}
