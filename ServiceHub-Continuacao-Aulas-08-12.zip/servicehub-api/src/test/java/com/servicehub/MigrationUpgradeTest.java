package com.servicehub;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.sql.DriverManager;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;

class MigrationUpgradeTest {
  @Test
  void migrateAnExistingDatabaseWithoutLosingItsRecords() throws Exception {
    String url = "jdbc:h2:mem:upgrade;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1";
    Flyway.configure().dataSource(url, "sa", "").target("4").load().migrate();
    try (var connection = DriverManager.getConnection(url, "sa", "");
        var statement = connection.createStatement()) {
      statement.executeUpdate(
          "INSERT INTO users(full_name,email,password_hash) VALUES"
              + " ('Prestador','p@example.com','test-hash'),('Cliente','c@example.com','test-hash')");
      statement.executeUpdate(
          "INSERT INTO services(title,price,category,provider_id) VALUES"
              + " ('Manutenção',150,'TECNOLOGIA',1)");
    }
    Flyway.configure().dataSource(url, "sa", "").load().migrate();
    try (var connection = DriverManager.getConnection(url, "sa", "");
        var statement = connection.createStatement()) {
      try (var rows = statement.executeQuery("SELECT id, role FROM users ORDER BY id")) {
        assertThat(rows.next()).isTrue();
        assertThat(rows.getString("role")).isEqualTo("PROVIDER");
        assertThat(rows.next()).isTrue();
        assertThat(rows.getString("role")).isEqualTo("CLIENT");
        assertThat(rows.next()).isFalse();
      }
      try (var rows = statement.executeQuery("SELECT title FROM services WHERE id=1")) {
        assertThat(rows.next()).isTrue();
        assertThat(rows.getString(1)).isEqualTo("Manutenção");
      }
      assertThatThrownBy(() -> statement.executeUpdate("UPDATE users SET role='INVALID' WHERE id=1"))
          .isInstanceOf(java.sql.SQLException.class);
    }
  }
}
