# Entrega de continuação — ServiceHub (Aulas 08 a 12)

## Mapeamento dos requisitos

### Aula 08 — Segurança em APIs
- `SecurityConfig`: cadeia de filtros, sessões stateless e rotas por perfil.
- `CustomUserDetailsService`, `AuthenticationBeans` e `AuthController`: validação de credenciais pelo AuthenticationManager e BCrypt.
- DTOs: Bean Validation; `GlobalExceptionHandler`: erros padronizados.
- `TextSanitizer`: Apache Commons Text aplicado na camada de serviço para textos livres.
- `docs/seguranca-owasp.md`: revisão de riscos OWASP e controles/limitações.

### Aula 09 — JWT e padrões de API
- `JwtService` e `JwtAuthenticationFilter`: assinatura, validade, expiração e authorities.
- `@PreAuthorize`: controle por role nos controllers e na mutation GraphQL.
- GraphQL implementa `providers`, `servicesByProvider` e `bookService`, além de `services` e `service`.
- `ServiceHubIntegrationTest`: testes de login, consulta GraphQL e agendamento com token.
- `scripts/benchmark-rest-graphql.ps1`: medição de latência e tamanho de resposta REST/GraphQL.

### Aula 10 — Testes automatizados
- `ServiceOfferingServiceTest`: testes unitários isolados com Mockito para regras de negócio.
- `TextSanitizerTest` e `JwtServiceTest`: testes unitários.
- `ServiceHubIntegrationTest` e `MigrationUpgradeTest`: testes de integração com Spring Boot, MockMvc e H2.

### Aula 11 — Desempenho PostgreSQL
- Migrations adicionam índices para filtros, relações e ordenação comuns.
- `docs/analise-desempenho-postgresql.md` descreve `EXPLAIN (ANALYZE, BUFFERS)`, `ANALYZE`, sargabilidade e como registrar medições reais.

### Aula 12 — Docker Compose
- `docker-compose.yml`: API + PostgreSQL, rede Compose, volume persistente, dependência com `service_healthy`, healthcheck da API, restart e logging rotativo.
- `.env.example` e `.gitignore`: variáveis documentadas e arquivo `.env` ignorado.
- `docker-compose.dev.yml` e `docker-compose.prod.yml`: exemplos de overrides para separar configurações de desenvolvimento e produção.
- `Dockerfile`: build multi-stage e processo sem root.

## Verificação obrigatória antes da entrega

Execute em ambiente com Java 21 e Maven:

```bash
mvn clean verify
```

Depois, com Docker Desktop ativo:

```bash
cp .env.example .env
# Edite .env e substitua APP_JWT_SECRET por um segredo aleatório forte
docker compose config
docker compose up --build -d
docker compose ps
docker compose logs --tail=100 api
```

No PowerShell do Windows, copie o arquivo em vez de usar `cp` se necessário:

```powershell
Copy-Item .env.example .env
```

Teste o login em `POST /api/v1/auth/login`, o Swagger em `/swagger-ui.html` e o GraphiQL em `/graphiql`. Rode o benchmark depois de criar dados suficientes e guarde o CSV real.

## Limites declarados

A comparação de performance e o funcionamento real do Docker dependem de execução no computador do aluno. O código e os roteiros estão incluídos, mas não se deve alegar que o benchmark foi executado nem que os testes passaram até executar os comandos acima. O escaping HTML reduz risco de injeção em conteúdo de texto, mas não substitui uma revisão de segurança completa nem controles de autorização por propriedade de cada registro (BOLA) em ambiente de produção.
