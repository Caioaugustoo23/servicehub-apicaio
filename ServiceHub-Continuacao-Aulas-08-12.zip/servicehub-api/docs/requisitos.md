# Correspondência de requisitos — ServiceHub API

Caio Augusto Martins de Andrade — matrícula 2411945.

| Requisito | Implementação |
|---|---|
| Java 21, Spring Boot 3, Maven | `pom.xml` |
| Camadas, DTOs e regras de negócio | `controller`, `service`, `repository`, `model`, `dto`, `exception` |
| CRUD, PATCH, filtros e paginação | Controllers dos quatro recursos, `PageResponse`, `Specification` |
| Banco versionado | Flyway V1–V6, Hibernate `ddl-auto=validate`, perfis local/postgres |
| Validação e erros | Bean Validation, `@Valid`, `GlobalExceptionHandler`, `ErrorResponse` |
| Senhas seguras | BCrypt |
| Login JWT e controle de acesso | `POST /api/v1/auth/login`, assinatura HS256, expiração e filtro por papel |
| API alternativa | Consultas GraphQL em `POST /graphql` |
| Testes automatizados | `ServiceHubIntegrationTest`, `MigrationUpgradeTest`, `JwtServiceTest` |
| Índices e desempenho | Migration V6 e `docs/analise-desempenho-postgresql.md` |
| Docker Compose | `Dockerfile`, `docker-compose.yml`, volume, variáveis e healthcheck do PostgreSQL |
| Documentação | Swagger/OpenAPI, `docs/openapi.json`, diagrama e roteiro de apresentação |

## Estado da validação

As alterações foram preparadas no código-fonte. Como o ambiente de edição não dispõe de Maven nem Docker, a compilação e a execução final de testes/containers ainda precisam ser confirmadas localmente antes da entrega. Consulte `docs/verificacao.md`.
