# Diagrama de endpoints do ServiceHub API

**Caio Augusto Martins de Andrade - matrícula 2411945**

Versão v1.0.0. Base local: http://localhost:8080. Swagger: /swagger-ui.html. OpenAPI: /v3/api-docs.

## Recursos e relacionamentos

```mermaid

flowchart LR
  U["Usuários /api/v1/users<br/>GET · POST<br/>/{id}: GET · PUT · PATCH · DELETE"]
  S["Serviços /api/v1/services<br/>GET · POST<br/>/{id}: GET · PUT · PATCH · DELETE"]
  P["Solicitações /api/v1/service-requests<br/>GET · POST<br/>/{id}: GET · PUT · PATCH · DELETE"]
  R["Avaliações /api/v1/reviews<br/>GET · POST<br/>/{id}: GET · PUT · PATCH · DELETE"]
  U -->|PROVIDER oferece| S
  U -->|CLIENT contrata| P
  S -->|origina| P
  P -->|concluída recebe até uma| R
  US["GET /users/{id}/services"] --- U
  UP["GET /users/{id}/service-requests"] --- P
  SR["GET /services/{id}/reviews"] --- R


```

## Convenções

Os corpos usam JSON. POST devolve 201 e Location. PUT exige todos os campos obrigatórios. PATCH altera somente os campos enviados, preserva os omitidos e aceita null somente em campos opcionais. GET de coleção é paginado: content, page, size, totalElements e totalPages. Page inicia em zero, size tem padrão 20 e máximo 100. DELETE bem-sucedido retorna 204 sem corpo.

E-mails são únicos, serviços exigem PROVIDER ativo e pedidos novos exigem CLIENT ativo. Novos pedidos começam em PENDING. Avaliações exigem pedido COMPLETED e reviewerId igual ao cliente. O esquema JWT é somente documental, sem login ou autorização.

## GET /api/v1/users/{id}

Consulta os dados de uma pessoa cadastrada pelo ID.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: usuário. Formato: `UserResponse`.

- **400**: ID inválido. Formato: `ErrorResponse`.

- **404**: usuário inexistente. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## PUT /api/v1/users/{id}

Substitui nome, e-mail, senha, telefone, biografia, foto e situação do usuário.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Modelo: `UserInput`. Campos detalhados ao final.

```json

{
  "fullName": "Maria Silva",
  "email": "maria@example.com",
  "password": "senha12345",
  "phone": 11999999999,
  "bio": "Técnica em informática",
  "avatarUrl": "https://example.com/avatar.png",
  "active": true,
  "role": "PROVIDER"
}

```

**Respostas e status:**

- **200**: usuário atualizado. Formato: `UserResponse`.

- **400**: entrada inválida. Formato: `ErrorResponse`.

- **404**: usuário inexistente. Formato: `ErrorResponse`.

- **409**: e-mail de outro usuário. Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## DELETE /api/v1/users/{id}

Remove o usuário apenas se ele não possuir serviços, pedidos como cliente ou avaliações vinculadas.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **204**: excluído. Formato: `sem corpo`.

- **400**: ID inválido. Formato: `ErrorResponse`.

- **404**: usuário inexistente. Formato: `ErrorResponse`.

- **409**: existem vínculos. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## PATCH /api/v1/users/{id}

Altera somente os campos enviados do usuário. Senha omitida permanece inalterada. Não permite mudar papel se houver serviços ou pedidos associados. Campos opcionais podem ser limpos com null. Campos obrigatórios não aceitam null. Campos desconhecidos são rejeitados.

**Parâmetros:**

- `id` (path, obrigatório): ID do recurso

**Corpo da requisição:**

Modelo: `UserPatchInput`. Campos detalhados ao final.

```json

{
  "phone": 11999999999
}

```

**Respostas e status:**

- **200**: Recurso atualizado Formato: `UserResponse`.

- **400**: Dados inválidos Formato: `ErrorResponse`.

- **404**: Recurso ou referência inexistente Formato: `ErrorResponse`.

- **409**: Conflito de negócio Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/v1/services/{id}

Consulta título, preço, categoria e ID do prestador de uma oferta.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: serviço. Formato: `ServiceOfferingResponse`.

- **400**: ID inválido. Formato: `ErrorResponse`.

- **404**: serviço inexistente. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## PUT /api/v1/services/{id}

Substitui título, descrição, preço, categoria, prestador e disponibilidade da oferta.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Modelo: `ServiceOfferingInput`. Campos detalhados ao final.

```json

{
  "title": "Manutenção de computador",
  "description": "Limpeza e diagnóstico",
  "price": 150.0,
  "category": "TECNOLOGIA",
  "providerId": 1,
  "active": true
}

```

**Respostas e status:**

- **200**: serviço atualizado. Formato: `ServiceOfferingResponse`.

- **400**: entrada inválida. Formato: `ErrorResponse`.

- **404**: serviço ou prestador ausente. Formato: `ErrorResponse`.

- **409**: prestador inativo. Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## DELETE /api/v1/services/{id}

Remove a oferta somente se nenhum pedido estiver associado a ela.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **204**: excluído. Formato: `sem corpo`.

- **400**: ID inválido. Formato: `ErrorResponse`.

- **404**: serviço inexistente. Formato: `ErrorResponse`.

- **409**: serviço possui pedidos. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## PATCH /api/v1/services/{id}

Altera somente os campos enviados da oferta, validando preço e prestador PROVIDER ativo. Campos opcionais podem ser limpos com null. Campos obrigatórios não aceitam null. Campos desconhecidos são rejeitados.

**Parâmetros:**

- `id` (path, obrigatório): ID do recurso

**Corpo da requisição:**

Modelo: `ServiceOfferingPatchInput`. Campos detalhados ao final.

```json

{
  "price": 150.0
}

```

**Respostas e status:**

- **200**: Recurso atualizado Formato: `ServiceOfferingResponse`.

- **400**: Dados inválidos Formato: `ErrorResponse`.

- **404**: Recurso ou referência inexistente Formato: `ErrorResponse`.

- **409**: Conflito de negócio Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/v1/service-requests/{id}

Consulta a contratação identificada, incluindo agendamento e observações.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: pedido. Formato: `ServiceRequestResponse`.

- **400**: ID inválido. Formato: `ErrorResponse`.

- **404**: pedido inexistente. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## PUT /api/v1/service-requests/{id}

Atualiza status, agendamento e observações. Exige os mesmos IDs de cliente e serviço e preserva totalPrice.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Modelo: `ServiceRequestInput`. Campos detalhados ao final.

```json

{
  "serviceId": 1,
  "clientId": 2,
  "status": "PENDING",
  "scheduledAt": "2026-10-20T14:00:00",
  "notes": "Computador não liga"
}

```

**Respostas e status:**

- **200**: pedido atualizado. Formato: `ServiceRequestResponse`.

- **400**: entrada inválida. Formato: `ErrorResponse`.

- **404**: pedido ou referência ausente. Formato: `ErrorResponse`.

- **409**: estado ou vínculo inválido. Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## DELETE /api/v1/service-requests/{id}

Remove a contratação somente se ela ainda não possuir avaliação vinculada.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **204**: excluído. Formato: `sem corpo`.

- **400**: ID inválido. Formato: `ErrorResponse`.

- **404**: pedido inexistente. Formato: `ErrorResponse`.

- **409**: pedido possui avaliação. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## PATCH /api/v1/service-requests/{id}

Altera status, agendamento ou observações. Cliente e serviço não podem mudar. Preserva o preço contratado e valida transições. Campos opcionais podem ser limpos com null. Campos obrigatórios não aceitam null. Campos desconhecidos são rejeitados.

**Parâmetros:**

- `id` (path, obrigatório): ID do recurso

**Corpo da requisição:**

Modelo: `ServiceRequestPatchInput`. Campos detalhados ao final.

```json

{
  "status": "PENDING"
}

```

**Respostas e status:**

- **200**: Recurso atualizado Formato: `ServiceRequestResponse`.

- **400**: Dados inválidos Formato: `ErrorResponse`.

- **404**: Recurso ou referência inexistente Formato: `ErrorResponse`.

- **409**: Conflito de negócio Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/v1/reviews/{id}

Consulta os detalhes de uma avaliação específica pelo ID.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: avaliação. Formato: `ReviewResponse`.

- **400**: ID inválido. Formato: `ErrorResponse`.

- **404**: avaliação inexistente. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## PUT /api/v1/reviews/{id}

Substitui nota e comentário, mantendo o pedido e o avaliador originais. O pedido deve continuar concluído.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Modelo: `ReviewInput`. Campos detalhados ao final.

```json

{
  "requestId": 1,
  "reviewerId": 2,
  "rating": 5,
  "comment": "Ótimo atendimento"
}

```

**Respostas e status:**

- **200**: avaliação atualizada. Formato: `ReviewResponse`.

- **400**: entrada inválida. Formato: `ErrorResponse`.

- **404**: avaliação ou referência ausente. Formato: `ErrorResponse`.

- **409**: vínculos ou regra inválidos. Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## DELETE /api/v1/reviews/{id}

Exclui somente a avaliação. O pedido, o serviço e o usuário permanecem cadastrados.

**Parâmetros:**

- `id` (path, obrigatório): Identificador do recurso

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **204**: excluída. Formato: `sem corpo`.

- **400**: ID inválido. Formato: `ErrorResponse`.

- **404**: avaliação inexistente. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## PATCH /api/v1/reviews/{id}

Altera nota e comentário da avaliação. Pedido e avaliador não podem mudar. Campos opcionais podem ser limpos com null. Campos obrigatórios não aceitam null. Campos desconhecidos são rejeitados.

**Parâmetros:**

- `id` (path, obrigatório): ID do recurso

**Corpo da requisição:**

Modelo: `ReviewPatchInput`. Campos detalhados ao final.

```json

{
  "rating": 5
}

```

**Respostas e status:**

- **200**: Recurso atualizado Formato: `ReviewResponse`.

- **400**: Dados inválidos Formato: `ErrorResponse`.

- **404**: Recurso ou referência inexistente Formato: `ErrorResponse`.

- **409**: Conflito de negócio Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/v1/users

Retorna uma página de usuários. page começa em 0, size tem máximo de 100 e sort aceita campo,direção. Os filtros informados são combinados.

**Parâmetros:**

- `email` (query, opcional): E-mail exato, sem diferença entre maiúsculas e minúsculas

- `page` (query, opcional): Zero-based page index (0..N)

- `size` (query, opcional): The size of the page to be returned

- `sort` (query, opcional): Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: Página de usuários. Formato: `PageResponseUserResponse`.

- **400**: Parâmetros inválidos. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## POST /api/v1/users

Cadastra uma pessoa como possível cliente ou prestador. Normaliza o e-mail e armazena a senha com hash BCrypt.

**Parâmetros:**

Nenhum.

**Corpo da requisição:**

Modelo: `UserInput`. Campos detalhados ao final.

```json

{
  "fullName": "Maria Silva",
  "email": "maria@example.com",
  "password": "senha12345",
  "phone": 11999999999,
  "bio": "Técnica em informática",
  "avatarUrl": "https://example.com/avatar.png",
  "active": true,
  "role": "PROVIDER"
}

```

**Respostas e status:**

- **201**: usuário criado. Formato: `UserResponse`.

- **400**: entrada inválida. Formato: `ErrorResponse`.

- **409**: e-mail já cadastrado. Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/v1/services

Retorna uma página de serviços. page começa em 0, size tem máximo de 100 e sort aceita campo,direção. Os filtros informados são combinados.

**Parâmetros:**

- `category` (query, opcional): Categoria do serviço

- `minPrice` (query, opcional): Preço mínimo inclusivo

- `maxPrice` (query, opcional): Preço máximo inclusivo

- `active` (query, opcional): Filtrar disponibilidade

- `providerId` (query, opcional): ID do prestador

- `page` (query, opcional): Zero-based page index (0..N)

- `size` (query, opcional): The size of the page to be returned

- `sort` (query, opcional): Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: Página de serviços. Formato: `PageResponseServiceOfferingResponse`.

- **400**: Parâmetros inválidos. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## POST /api/v1/services

Publica uma oferta de serviço vinculada a um prestador existente e ativo.

**Parâmetros:**

Nenhum.

**Corpo da requisição:**

Modelo: `ServiceOfferingInput`. Campos detalhados ao final.

```json

{
  "title": "Manutenção de computador",
  "description": "Limpeza e diagnóstico",
  "price": 150.0,
  "category": "TECNOLOGIA",
  "providerId": 1,
  "active": true
}

```

**Respostas e status:**

- **201**: serviço criado. Formato: `ServiceOfferingResponse`.

- **400**: entrada inválida. Formato: `ErrorResponse`.

- **404**: prestador inexistente. Formato: `ErrorResponse`.

- **409**: prestador inativo. Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/v1/service-requests

Retorna uma página de pedidos de serviço. page começa em 0, size tem máximo de 100 e sort aceita campo,direção. Os filtros informados são combinados.

**Parâmetros:**

- `status` (query, opcional): Estado das solicitações

- `page` (query, opcional): Zero-based page index (0..N)

- `size` (query, opcional): The size of the page to be returned

- `sort` (query, opcional): Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: Página de pedidos de serviço. Formato: `PageResponseServiceRequestResponse`.

- **400**: Parâmetros inválidos. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## POST /api/v1/service-requests

Contrata um serviço para um cliente. Inicia em PENDING e copia o preço atual da oferta para totalPrice.

**Parâmetros:**

Nenhum.

**Corpo da requisição:**

Modelo: `ServiceRequestInput`. Campos detalhados ao final.

```json

{
  "serviceId": 1,
  "clientId": 2,
  "status": "PENDING",
  "scheduledAt": "2026-10-20T14:00:00",
  "notes": "Computador não liga"
}

```

**Respostas e status:**

- **201**: pedido criado. Formato: `ServiceRequestResponse`.

- **400**: entrada inválida. Formato: `ErrorResponse`.

- **404**: serviço ou cliente ausente. Formato: `ErrorResponse`.

- **409**: contratação incompatível. Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/v1/reviews

Retorna uma página de avaliações. page começa em 0, size tem máximo de 100 e sort aceita campo,direção. Os filtros informados são combinados.

**Parâmetros:**

- `page` (query, opcional): Zero-based page index (0..N)

- `size` (query, opcional): The size of the page to be returned

- `sort` (query, opcional): Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: Página de avaliações. Formato: `PageResponseReviewResponse`.

- **400**: Parâmetros inválidos. Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## POST /api/v1/reviews

Registra nota e comentário para um pedido concluído, indicando como avaliador o cliente do pedido.

**Parâmetros:**

Nenhum.

**Corpo da requisição:**

Modelo: `ReviewInput`. Campos detalhados ao final.

```json

{
  "requestId": 1,
  "reviewerId": 2,
  "rating": 5,
  "comment": "Ótimo atendimento"
}

```

**Respostas e status:**

- **201**: avaliação criada. Formato: `ReviewResponse`.

- **400**: entrada inválida. Formato: `ErrorResponse`.

- **404**: pedido ou avaliador ausente. Formato: `ErrorResponse`.

- **409**: regra de avaliação violada. Formato: `ErrorResponse`.

- **415**: tipo de mídia não suportado; envie Content-Type: application/json.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/v1/users/{id}/services

Retorna uma página dos serviços ativos associados ao usuário. Usuário inexistente retorna 404.

**Parâmetros:**

- `id` (path, obrigatório): ID do usuário

- `page` (query, opcional): Zero-based page index (0..N)

- `size` (query, opcional): The size of the page to be returned

- `sort` (query, opcional): Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: Página de resultados Formato: `PageResponseServiceOfferingResponse`.

- **400**: Parâmetro inválido Formato: `ErrorResponse`.

- **404**: Recurso principal não encontrado Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/v1/users/{id}/service-requests

Retorna uma página das solicitações nas quais o usuário informado é o cliente contratante.

**Parâmetros:**

- `id` (path, obrigatório): ID do usuário cliente

- `page` (query, opcional): Zero-based page index (0..N)

- `size` (query, opcional): The size of the page to be returned

- `sort` (query, opcional): Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: Página de resultados Formato: `PageResponseServiceRequestResponse`.

- **400**: Parâmetro inválido Formato: `ErrorResponse`.

- **404**: Recurso principal não encontrado Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/v1/services/{id}/reviews

Retorna uma página das avaliações de pedidos concluídos vinculados à oferta informada.

**Parâmetros:**

- `id` (path, obrigatório): ID da oferta

- `page` (query, opcional): Zero-based page index (0..N)

- `size` (query, opcional): The size of the page to be returned

- `sort` (query, opcional): Sorting criteria in the format: property,(asc|desc). Default sort order is ascending. Multiple sort criteria are supported.

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: Página de resultados Formato: `PageResponseReviewResponse`.

- **400**: Parâmetro inválido Formato: `ErrorResponse`.

- **404**: Recurso principal não encontrado Formato: `ErrorResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/status

Verifica se o servidor responde a requisições.

**Parâmetros:**

Nenhum.

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: OK Formato: `StatusResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/info

Retorna status, versão e mensagem da aplicação.

**Parâmetros:**

Nenhum.

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: OK Formato: `StatusResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## GET /api/hello

Retorna mensagem de sucesso em JSON, conforme a entrega da aula 3.

**Parâmetros:**

Nenhum.

**Corpo da requisição:**

Sem corpo.

**Respostas e status:**

- **200**: OK Formato: `StatusResponse`.

Falhas inesperadas retornam 500 com o erro padronizado. Métodos ou representações incompatíveis podem produzir 405 ou 406.

## Modelos de dados

### UserInput

Dados para criar ou substituir User. PUT exige todos os campos obrigatórios.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `fullName` | string | Sim | Nome completo |

| `email` | string | Sim | E-mail único |

| `password` | string | Sim | Senha de 8 a 60 caracteres; somente entrada |

| `phone` | string | Não | Telefone opcional |

| `bio` | string | Não | Apresentação do usuário |

| `avatarUrl` | string | Não | URL opcional da foto |

| `active` | boolean | Sim | Cadastro ativo |

| `role` | string | Sim | Papel do usuário Valores: CLIENT, PROVIDER. |

### ErrorResponse

Erro HTTP padronizado, sem detalhes internos do servidor

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `timestamp` | string | Não | Instante UTC |

| `status` | integer | Não | Código HTTP |

| `error` | string | Não | Nome do status |

| `message` | string | Não | Mensagem para o consumidor |

| `path` | string | Não | Caminho solicitado |

| `fieldErrors` | object | Não | Mensagens por campo |

### UserResponse

Representação de User, sem senha ou hash.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `id` | integer | Não | Identificador |

| `fullName` | string | Não | Nome completo |

| `email` | string | Não | E-mail único |

| `phone` | string | Não | Telefone opcional |

| `bio` | string | Não | Apresentação do usuário |

| `avatarUrl` | string | Não | URL opcional da foto |

| `active` | boolean | Não | Cadastro ativo |

| `role` | string | Não | Papel do usuário Valores: CLIENT, PROVIDER. |

| `createdAt` | string | Não | Data de criação |

| `updatedAt` | string | Não | Data da última alteração |

### ServiceOfferingInput

Dados para criar ou substituir ServiceOffering. PUT exige todos os campos obrigatórios.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `title` | string | Sim | Título do serviço |

| `description` | string | Não | Descrição do serviço |

| `price` | number | Sim | Preço em reais |

| `category` | string | Sim | Categoria Valores: TECNOLOGIA, LIMPEZA, MANUTENCAO, EDUCACAO, BELEZA, OUTROS. |

| `providerId` | integer | Sim | ID de usuário prestador |

| `active` | boolean | Sim | Serviço disponível |

### ServiceOfferingResponse

Representação de ServiceOffering, sem senha ou hash.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `id` | integer | Não | Identificador |

| `title` | string | Não | Título do serviço |

| `description` | string | Não | Descrição do serviço |

| `price` | number | Não | Preço em reais |

| `category` | string | Não | Categoria Valores: TECNOLOGIA, LIMPEZA, MANUTENCAO, EDUCACAO, BELEZA, OUTROS. |

| `providerId` | integer | Não | ID de usuário prestador |

| `active` | boolean | Não | Serviço disponível |

| `createdAt` | string | Não | Data de criação |

| `updatedAt` | string | Não | Data da última alteração |

### ServiceRequestInput

Dados para criar ou substituir ServiceRequest. PUT exige todos os campos obrigatórios.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `serviceId` | integer | Sim | ID do serviço |

| `clientId` | integer | Sim | ID do usuário cliente |

| `status` | string | Sim | Situação; criação exige PENDING Valores: PENDING, ACCEPTED, IN_PROGRESS, COMPLETED, CANCELLED. |

| `scheduledAt` | string | Não | Agendamento opcional, horário local |

| `notes` | string | Não | Observações |

### ServiceRequestResponse

Representação de ServiceRequest, sem senha ou hash.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `id` | integer | Não | Identificador |

| `serviceId` | integer | Não | ID do serviço |

| `clientId` | integer | Não | ID do usuário cliente |

| `status` | string | Não | Situação; criação exige PENDING Valores: PENDING, ACCEPTED, IN_PROGRESS, COMPLETED, CANCELLED. |

| `scheduledAt` | string | Não | Agendamento opcional, horário local |

| `notes` | string | Não | Observações |

| `totalPrice` | number | Não | Preço registrado no pedido |

| `createdAt` | string | Não | Data de criação |

| `updatedAt` | string | Não | Data da última alteração |

### ReviewInput

Dados para criar ou substituir Review. PUT exige todos os campos obrigatórios.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `requestId` | integer | Sim | Pedido concluído avaliado |

| `reviewerId` | integer | Sim | ID do cliente do pedido |

| `rating` | integer | Sim | Nota de 1 a 5 |

| `comment` | string | Não | Comentário |

### ReviewResponse

Representação de Review, sem senha ou hash.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `id` | integer | Não | Identificador |

| `requestId` | integer | Não | Pedido concluído avaliado |

| `reviewerId` | integer | Não | ID do cliente do pedido |

| `rating` | integer | Não | Nota de 1 a 5 |

| `comment` | string | Não | Comentário |

| `createdAt` | string | Não | Data de criação |

| `updatedAt` | string | Não | Data da última alteração |

### UserPatchInput

Dados para criar ou substituir User. PATCH altera somente campos enviados; null limpa campos opcionais.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `fullName` | string | Não | Nome completo |

| `email` | string | Não | E-mail único |

| `password` | string | Não | Senha de 8 a 60 caracteres; somente entrada |

| `phone` | string | Não | Telefone opcional |

| `bio` | string | Não | Apresentação do usuário |

| `avatarUrl` | string | Não | URL opcional da foto |

| `active` | boolean | Não | Cadastro ativo |

| `role` | string | Não | Papel do usuário Valores: CLIENT, PROVIDER. |

### ServiceOfferingPatchInput

Dados para criar ou substituir ServiceOffering. PATCH altera somente campos enviados; null limpa campos opcionais.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `title` | string | Não | Título do serviço |

| `description` | string | Não | Descrição do serviço |

| `price` | number | Não | Preço em reais |

| `category` | string | Não | Categoria Valores: TECNOLOGIA, LIMPEZA, MANUTENCAO, EDUCACAO, BELEZA, OUTROS. |

| `providerId` | integer | Não | ID de usuário prestador |

| `active` | boolean | Não | Serviço disponível |

### ServiceRequestPatchInput

Dados para criar ou substituir ServiceRequest. PATCH altera somente campos enviados; null limpa campos opcionais.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `serviceId` | integer | Não | ID do serviço |

| `clientId` | integer | Não | ID do usuário cliente |

| `status` | string | Não | Situação; criação exige PENDING Valores: PENDING, ACCEPTED, IN_PROGRESS, COMPLETED, CANCELLED. |

| `scheduledAt` | string | Não | Agendamento opcional, horário local |

| `notes` | string | Não | Observações |

### ReviewPatchInput

Dados para criar ou substituir Review. PATCH altera somente campos enviados; null limpa campos opcionais.

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `requestId` | integer | Não | Pedido concluído avaliado |

| `reviewerId` | integer | Não | ID do cliente do pedido |

| `rating` | integer | Não | Nota de 1 a 5 |

| `comment` | string | Não | Comentário |

### PageResponseUserResponse

Página de resultados; page começa em zero e size tem limite de 100

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `content` | array | Não | Registros desta página |

| `page` | integer | Não | Página atual |

| `size` | integer | Não | Tamanho solicitado |

| `totalElements` | integer | Não | Quantidade total de registros |

| `totalPages` | integer | Não | Quantidade total de páginas |

### PageResponseServiceOfferingResponse

Página de resultados; page começa em zero e size tem limite de 100

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `content` | array | Não | Registros desta página |

| `page` | integer | Não | Página atual |

| `size` | integer | Não | Tamanho solicitado |

| `totalElements` | integer | Não | Quantidade total de registros |

| `totalPages` | integer | Não | Quantidade total de páginas |

### PageResponseServiceRequestResponse

Página de resultados; page começa em zero e size tem limite de 100

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `content` | array | Não | Registros desta página |

| `page` | integer | Não | Página atual |

| `size` | integer | Não | Tamanho solicitado |

| `totalElements` | integer | Não | Quantidade total de registros |

| `totalPages` | integer | Não | Quantidade total de páginas |

### PageResponseReviewResponse

Página de resultados; page começa em zero e size tem limite de 100

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `content` | array | Não | Registros desta página |

| `page` | integer | Não | Página atual |

| `size` | integer | Não | Tamanho solicitado |

| `totalElements` | integer | Não | Quantidade total de registros |

| `totalPages` | integer | Não | Quantidade total de páginas |

### StatusResponse

Estado da aplicação

| Campo | Tipo | Obrigatório | Descrição |

|---|---|---|---|

| `status` | string | Não | Estado |

| `versao` | string | Não | Versão |

| `mensagem` | string | Não | Mensagem |

## Exemplo de resposta paginada

```json

{
  "content": [
    {
      "id": 1,
      "title": "Manutenção de computador",
      "description": "Limpeza e diagnóstico",
      "price": 150.0,
      "category": "TECNOLOGIA",
      "providerId": 1,
      "active": true,
      "createdAt": "2026-09-14T10:00:00",
      "updatedAt": "2026-09-14T10:00:00"
    }
  ],
  "page": 0,
  "size": 20,
  "totalElements": 1,
  "totalPages": 1
}

```

## Erros padronizados

```json

{
  "timestamp": "2026-09-21T14:00:00Z",
  "status": 400,
  "error": "Bad Request",
  "message": "Dados inválidos",
  "path": "/api/v1/services",
  "fieldErrors": {
    "price": "deve ser maior que ou igual a 0.01"
  }
}

```
