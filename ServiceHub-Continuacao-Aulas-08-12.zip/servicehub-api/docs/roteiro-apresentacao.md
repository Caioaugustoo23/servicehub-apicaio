# Apresentação do ServiceHub API — continuação das aulas 08 a 12

Caio Augusto Martins de Andrade — matrícula 2411945. Duração sugerida: 8–10 minutos.

1. **0:00–0:45 — Objetivo:** a plataforma conecta clientes e prestadores. Prestadores publicam serviços; clientes abrem pedidos e avaliam serviços concluídos.
2. **0:45–1:30 — Arquitetura:** Java 21 e Spring Boot. O Controller recebe HTTP, o Service aplica regras e o Repository acessa o banco. JPA/Hibernate mapeia entidades; Flyway versiona o esquema.
3. **1:30–2:15 — Validação e erros:** mostrar `@Valid`, DTOs e respostas 400/404/409. Senhas são armazenadas com BCrypt, nunca em texto puro.
4. **2:15–3:30 — Login JWT:** cadastrar um CLIENT ou PROVIDER, autenticar em `POST /api/v1/auth/login`, copiar `accessToken` e usar `Authorization: Bearer ...`. Explicar que o token tem assinatura HS256 e expiração; os papéis restringem operações.
5. **3:30–4:15 — REST e GraphQL:** REST continua sendo a interface principal. GraphQL em `/graphql` oferece consultas de leitura, por exemplo `query { services { id title price category active } }`, permitindo escolher os campos necessários.
6. **4:15–5:15 — Testes:** executar `mvn clean verify`. Explicar que os testes de integração usam H2 isolado; `JwtServiceTest` testa token válido e rejeita token adulterado. Só mostrar o resultado depois de executar os testes no computador.
7. **5:15–6:15 — PostgreSQL e desempenho:** mostrar a migration V6 e `docs/analise-desempenho-postgresql.md`. `EXPLAIN (ANALYZE, BUFFERS)` mede a consulta real; não afirmar melhora sem comparar medições antes/depois.
8. **6:15–7:30 — Docker Compose:** mostrar `docker-compose.yml`, API, PostgreSQL, volume nomeado, variáveis de ambiente e healthcheck do banco. A API usa `postgres` como hostname dentro da rede Compose.
9. **7:30–9:00 — Conclusão e limites:** resumir que o projeto passou a incluir autenticação, autorização por papel, GraphQL, testes de JWT, índices e orquestração. Distinguir o que foi implementado do que ainda precisa ser validado no ambiente real: build completo, testes e execução com Docker/PostgreSQL.

## Preparação

- Copie `.env.example` para `.env` e troque `DB_PASSWORD` e `APP_JWT_SECRET` por valores próprios.
- Com Docker Desktop ativo, execute `docker compose up --build -d` e confira `docker compose logs -f api`.
- Ou execute `mvn clean verify` para validar build e testes.
- Não use o segredo JWT de desenvolvimento em ambiente público. O cadastro público não pode criar ADMIN; o administrador precisa ser provisionado de forma controlada.
- Use somente dados fictícios na demonstração.
