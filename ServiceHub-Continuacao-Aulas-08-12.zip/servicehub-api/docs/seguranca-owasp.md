# Segurança e validação — Aula 08

## Controles implementados
- Spring Security com cadeia de filtros e sessões STATELESS.
- Login por `AuthenticationManager` e `UserDetailsService`; senhas armazenadas com BCrypt.
- JWT assinado com HS256, expiração validada e roles incluídas no payload.
- Sanitização de texto livre na camada de serviço com Apache Commons Text (`StringEscapeUtils.escapeHtml4`), sem concatenar entrada em SQL.
- Bean Validation nos DTOs com `@Valid`, `@NotBlank`, `@Email`, `@Size`, `@Positive`, `@NotNull` e limites numéricos.
- `@RestControllerAdvice` padroniza erros de validação e negócio.
- Consultas ao banco usam parâmetros JPA/Criteria, sem concatenar entrada do usuário em SQL.
- `.env` é ignorado pelo Git; `.env.example` contém apenas valores de desenvolvimento.
- O cadastro público não permite criar usuários com papel ADMIN.

## Sanitização de entradas
A API valida tamanho e formato dos campos nos DTOs e aplica escaping HTML em nome, biografia, título, descrição, observações e comentário na camada de serviço usando Apache Commons Text. O frontend ainda deve aplicar escaping contextual ao renderizar dados. URL de avatar não é buscada pelo backend; o frontend deve validar esquema e host antes de carregar a imagem.

## OWASP API Security Top 10 — revisão aplicada
- **Broken Object Level Authorization (BOLA):** endpoints recebem IDs; uma aplicação de produção deve verificar a propriedade do recurso por usuário. As regras por role estão aplicadas na cadeia de segurança e o resolver `bookService` usa o cliente do token, não um `clientId` enviado pelo cliente.
- **Broken Authentication:** login uniforme para credenciais inválidas, BCrypt, JWT com expiração e segredo externo à aplicação.
- **Broken Object Property Level Authorization:** DTOs de resposta não expõem `passwordHash`; cadastro público não pode atribuir ADMIN.
- **Unrestricted Resource Consumption:** paginação limita tamanho máximo a 100; definir rate limiting no gateway é recomendável para produção.
- **Broken Function Level Authorization:** regras por role na SecurityFilterChain e `@PreAuthorize` na mutation GraphQL.
- **Security Misconfiguration:** CSRF desabilitado apenas para API stateless; endpoints e GraphiQL devem ser desabilitados ou protegidos em produção.
- **Injection:** JPA/Criteria e validação de entrada reduzem risco de SQL injection.
- **SSRF:** não buscar URLs fornecidas por usuário no backend; caso o avatar seja baixado pelo servidor, adicionar allowlist de hosts e bloqueio de endereços privados.
- **Improper Inventory Management:** manter OpenAPI atualizado e não expor endpoints de diagnóstico em produção sem necessidade.
- **Unsafe Consumption of APIs:** validar e limitar respostas de serviços externos se integrações forem adicionadas.

> Nota: a lista acima é uma revisão de controles e riscos; não equivale a uma auditoria de segurança independente.
