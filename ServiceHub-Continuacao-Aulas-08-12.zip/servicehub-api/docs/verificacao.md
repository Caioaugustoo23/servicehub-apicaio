# Verificação da continuação do ServiceHub

Projeto acadêmico de Caio Augusto Martins de Andrade — matrícula 2411945.

## O que foi acrescentado nesta versão

- Spring Security com filtro JWT HS256, validade configurável e autorização por papel.
- Endpoint `POST /api/v1/auth/login` com verificação de senha BCrypt.
- Consultas GraphQL em `/graphql` para listar e consultar ofertas de serviço.
- Teste unitário do JWT para token válido, token alterado e token malformado.
- Migration V6 para papel ADMIN e índices compostos.
- Dockerfile multi-stage e Compose para API + PostgreSQL, healthcheck do banco, volume nomeado e variáveis de ambiente.
- Guia `docs/analise-desempenho-postgresql.md` com `EXPLAIN (ANALYZE, BUFFERS)`.

## Estado da validação

A versão anterior possuía testes de integração e evidências HTTP em H2. Depois das alterações das aulas 08 a 12, **os testes e a inicialização completa ainda precisam ser executados no computador de desenvolvimento**: o ambiente desta geração não dispõe de Maven nem Docker para confirmar `mvn clean verify` ou `docker compose up --build`. Portanto, não trate a nova versão como build já aprovado.

Antes da entrega, execute `mvn clean verify`. Depois copie `.env.example` para `.env`, altere `DB_PASSWORD` e `APP_JWT_SECRET`, inicie o Docker Desktop e execute `docker compose up --build -d`. Verifique `docker compose logs -f api` e teste Swagger, login, uma rota protegida, GraphQL e as consultas SQL documentadas.

## Observações de segurança

O segredo padrão é somente para desenvolvimento local. Não exponha a API com esse segredo. O cadastro inicial e as consultas de leitura permanecem públicos para a demonstração; o cadastro público não permite atribuir o papel ADMIN. A criação de administradores deve ocorrer por processo administrativo controlado.
